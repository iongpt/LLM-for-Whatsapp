// Electron TypeScript definitions
/// <reference types="electron" />